---
name: Question template
about: Clear and concise questions
title: ''
labels: ''
assignees: ''

---

To make it easier for us to help you, please include as much useful information as possible.

## Version
Write the version of the Editor you are currently using.

## Additional context
Add any other context about the problem here.
