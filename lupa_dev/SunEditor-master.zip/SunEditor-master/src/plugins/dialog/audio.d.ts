import { DialogPlugin } from '../DialogPlugin';

declare const audio: DialogPlugin;

export default audio;