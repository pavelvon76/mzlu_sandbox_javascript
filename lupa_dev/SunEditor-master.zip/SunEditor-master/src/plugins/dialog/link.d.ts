import { DialogPlugin } from '../DialogPlugin';

declare const link: DialogPlugin;

export default link;