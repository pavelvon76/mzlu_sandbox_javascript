import { DialogPlugin } from '../DialogPlugin';

declare const image: DialogPlugin;

export default image;