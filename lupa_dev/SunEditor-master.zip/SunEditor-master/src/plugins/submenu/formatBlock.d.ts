import { SubmenuPlugin } from '../SubmenuPlugin';

declare const formatBlock: SubmenuPlugin;

export default formatBlock;