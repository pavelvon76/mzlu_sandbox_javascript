import { SubmenuPlugin } from '../SubmenuPlugin';

declare const hiliteColor: SubmenuPlugin;

export default hiliteColor;