import { Lang } from './Lang';

declare const ru: Lang;

export default ru;