import { Lang } from './Lang';

declare const es: Lang;

export default es;