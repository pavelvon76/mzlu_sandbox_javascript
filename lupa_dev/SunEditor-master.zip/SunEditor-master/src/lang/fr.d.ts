import { Lang } from './Lang';

declare const fr: Lang;

export default fr;