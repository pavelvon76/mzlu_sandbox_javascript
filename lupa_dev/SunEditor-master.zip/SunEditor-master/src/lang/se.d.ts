import { Lang } from './Lang';

declare const se: Lang;

export default se;