import { Lang } from './Lang';

declare const he: Lang;

export default he;