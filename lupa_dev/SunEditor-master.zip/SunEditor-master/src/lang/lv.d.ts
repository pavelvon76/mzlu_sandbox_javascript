import { Lang } from './Lang';

declare const lv: Lang;

export default lv;